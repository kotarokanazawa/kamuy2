﻿
JP   CADファイルのリクエスト：Your download from the 16.11.2022 on PARTcommunity/PARTserver/3Dfindit.com:

       お客様へ

       3D CAD download portal PARTcommunity/PARTserver/3Dfindit.com にリクエストされたCADデータをお送りします。添付ファイルをご確認ください。powered by CADENAS

       
	   
       AIS2020, NSFMKRRA10-131-F3-S6-KA5-A19-KB100.5-B11, NSFMKRRA10-131-F3-S6-KA5-A19-KB100_5-B11.iam
       AIS2020, NSFMKRRA10-131-F3-S6-KA5-A19-KB100.5-B11, NSFMKRRA10-131-F3-S6-KA5-A19-KB100_5-B11_s.ipt
       AIS2020, NSFMKRRA10-131-F3-S6-KA5-A19-KB100.5-B11, STWS10.ipt

       ご利用方法：

       
       添付ファイルは、圧縮ファイルです ("ZIP")。
       ファイルを解凍するには、解凍ソフトが必要です。 

       解凍ソフトをインストールしていない場合は、以下からダウンロードできます：
       7Zip® (https://7-zip.de) または WinZip® (https://www.winzip.com)

       ご利用条件は： https://www.cadenas.de/jp/terms-of-use-3d-cad-models
       
                   

       このメールはシステムの送信専用アドレスから送付されている自動送信メールです。ご返信を頂きましても確認できません。お問い合わせは、弊社のサポートまで直接ご連絡をお願いします。
       
       Best regards

       CADENAS GmbH
       support@cadenas.de




       >> 3DfindIT <<
       
       3DfindIT.comは次世代型のビジュアル検索エンジンです。世界中で利用可能な数百に及ぶメーカーカタログにある
       無数の3D CADデータやBIMモデルをクロールしています。3D形状検索、2Dスケッチ＆フォト検索、パラメトリックテキスト・
       変数入力などのインテリジェント検索機能を備えた3DfindIT.comは、これからの建築家・エンジニア・
       設計者にとって不可欠なプラットフォームです。



       >> Free APP for 3D CAD models <<
       
       スマートフォンやタブレットPCで 3D CAD models へアクセス 
       
       無料ダウンロードはこちらから： http://www.cadenas.de/en/app-store




       >> PARTcommunity - エンジニアのためのネットワークと情報のプラットフォーム <<
       
       ■ コンポーネントの使用例やアイデア 
       ■ エンジニア同士の情報交換

       ディスカッションへの参加は： http://www.partcommunity.com
       

       
